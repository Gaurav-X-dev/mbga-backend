# MBGA Delivery App - Backend API

Everything the delivery app can call. Generated from the running server, so this document and the API cannot disagree.

Regenerate with `python scripts/generate_delivery_api_docs.py`. Live, browsable version: **`{BASE_URL}/docs/delivery`**.


## Base URL

```
{BASE_URL}/api/v1/delivery
```

The `/delivery` segment is what makes a request a driver request. A token issued on this channel is rejected on `/merchant`, `/customer` and `/admin`, and theirs are rejected here.


## Headers

| Header | Value | When |
|---|---|---|
| `Authorization` | `Bearer <accessToken>` | Every endpoint except the OTP ones |
| `Content-Type` | `application/json` | Every request with a body |


## Errors

Every failure comes back in one shape:

```json
{
  "detail": {
    "code": "DELIVERY_NOT_READY",
    "message": "Order MBGA-R-0007 has not been dispatched yet...",
    "fields": [],
    "request_id": "0f3c9a1e-..."
  }
}
```

Show `message` to the driver and branch on `code` - never on the message text, which is written for people and will be reworded. Quote `request_id` when reporting a bug; it finds the exact request in the server logs.


> **If your HTTP client expects `{ "success": ..., "error": ... }`** - the shape in the original integration spec - say so and the server can be switched to it for this channel. It is one deployment flag (`DELIVERY_RESPONSE_ENVELOPE`). It is **off** today because turning it on also wraps the auth responses you are already parsing.


---

## The delivery flow

The order the calls have to happen in. This is the part the endpoint list cannot tell you, and getting it wrong is the difference between stock that reconciles and stock that does not.

```
1.  GET  /deliveries/today                      what am I delivering
2.  POST /deliveries/{id}/out-for-delivery      I have set off
3.  POST /deliveries/{id}/verify-location       where I am against the delivery site
4.  POST /deliveries/{id}/confirm               what I counted at the gate
5.  POST /deliveries/{id}/verify-customer-otp   the customer's code -> DONE
```

**Step 4 does not complete the delivery.** It records the counts and nothing else: no stock moves, the order does not advance, the customer is not told. It exists so the app can be backgrounded between counting cylinders and the customer finding their code without losing what the driver entered. Safe to call again.

**Step 5 is the delivery.** Only here do the cylinders come off the merchant's books, the order become `DELIVERED`, and the customer get their notification. Until it succeeds, nothing has happened.


### Where the customer's code comes from

It is **not** sent by SMS when the driver confirms. It is generated when the office dispatches the van, and it reaches the customer inside their own app's "out for delivery" notification. The customer therefore has it before the driver arrives, and neither of them needs a signal at the gate.

A wrong code returns `422` and costs one attempt out of ten. After ten the slip can only be closed from the office, so show the driver how many tries are left rather than letting them exhaust it.


### Statuses the app will see

| `status` | Meaning |
|---|---|
| `pending` | Assigned to this driver - either not dispatched yet, or dispatched and not started. |
| `out_for_delivery` | The driver has pressed Out for delivery. Derived from the slip's `started_at`, not a status of its own. |
| `completed` | Handed over and confirmed. |
| `failed` | Closed without delivering. Only the office can set this. |

### Errors worth handling by name

| `code` | HTTP | What happened |
|---|---|---|
| `DELIVERY_NOT_FOUND` | 404 | Not this driver's delivery. Never 403 - ids are guessable, so the server will not confirm one exists. |
| `DELIVERY_NOT_READY` | 409 | The office has not dispatched the van. Nothing has left the godown yet. |
| `DELIVERY_ALREADY_SETTLED` | 409 | Already delivered or failed. |
| `DELIVERY_QUANTITY_EXCEEDS_ALLOCATION` | 422 | More was handed over than the van carries. A part delivery is fine - only the quantity the slip allocated is not a ceiling the driver can exceed. |
| `DELIVERY_ITEM_NOT_ON_SLIP` | 422 | A cylinder type that is not on this slip. |
| `DELIVERY_EMPTIES_EXCEED_LOAD` | 422 | More empties than cylinders on the slip. |
| `DELIVERY_CODE_LOCKED` | 409 | Ten wrong codes. The office has to close it. |
| `DRIVER_HAS_ACTIVE_DELIVERIES` | 409 | Cannot go off duty with a van still out. |


---

## Authentication

Sign-in is by OTP on the driver's registered mobile. A token minted here works only on the delivery channel - it is refused by the merchant and customer APIs, and theirs are refused here.


### `POST /auth/logout`

**Logout**

Revokes the session of the given refresh token. Always returns 204, even when nothing was revoked.


**Request body**

| Field | Type | Required | Notes |
|---|---|---|---|
| `refresh_token` | string · nullable | no |  |
| `device_id` | string · nullable | no | Ignored. |


**Error statuses**: `422`


### `POST /auth/logout-all`

**Logout All**


**Error statuses**: `401`, `403`


### `GET /auth/me`

**Me**


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `user_id` | string | yes |  |
| `login_channel` | LoginChannel | yes |  |
| `user_type` | string | yes | CUSTOMER, DELIVERY_PARTNER, MERCHANT_STAFF or ADMIN. |
| `session_type` | string | yes | `access` (full app session) or `onboarding` (customer registration only). |
| `role` | string · nullable | no | Primary role code for this app, e.g. manager, driver, customer. |
| `active_roles` | string[] | no | Distinct role codes allowed on this app. |
| `account_status` | string | yes |  |
| `approval_status` | string · nullable | no | Merchant, delivery-profile or customer approval state. |
| `profile_completion_status` | string · nullable | no | Customer only: NOT_STARTED, INCOMPLETE or COMPLETE. |
| `next_action` | NextAction | yes |  |
| `merchant` | MerchantSummary · nullable | no | Merchant and delivery apps only. |
| `delivery_profile` | DeliveryProfileSummary · nullable | no | Delivery app only. |
| `customer_profile` | CustomerProfileSummary · nullable | no | Customer app only, once details are submitted. |
| `display_name` | string · nullable | no |  |
| `mobile_number` | string · nullable | no |  |
| `country_code` | string · nullable | no |  |
| `effective_permissions` | string[] | no |  |
| `status` | string | yes | Deprecated: same value as account_status. |
| `profile` | DeliveryProfileSummary · nullable | no | Deprecated: use delivery_profile or customer_profile. |


**Error statuses**: `401`, `403`


### `POST /auth/otp/request`

**Request Otp**


**Request body**

| Field | Type | Required | Notes |
|---|---|---|---|
| `mobile_number` | string | yes | Max 15 characters. |
| `country_code` | string | no | Defaults to `"+91"`. Max 5 characters. |
| `login_channel` | LoginChannel | no | Ignored: the app channel is taken from the URL. Accepts the name or the numeric code (1 CUSTOMER, 2 DELIVERY, 3 MERCHANT, 4 ADMIN). Defaults to `"CUSTOMER"`. |
| `device` | DeviceInfo · nullable | no |  |


**Error statuses**: `403`, `404`, `422`, `429`


### `POST /auth/otp/resend`

**Resend Otp**


**Request body**

| Field | Type | Required | Notes |
|---|---|---|---|
| `request_id` | string | yes | Max 36 characters. |
| `device` | DeviceInfo · nullable | no |  |


**Error statuses**: `400`, `403`, `404`, `422`, `429`


### `POST /auth/otp/verify`

**Verify Otp**


**Request body**

| Field | Type | Required | Notes |
|---|---|---|---|
| `request_id` | string | yes | Max 36 characters. |
| `mobile_number` | string · nullable | no | Ignored. |
| `country_code` | string | no | Ignored. Defaults to `"+91"`. Max 5 characters. |
| `login_channel` | LoginChannel | no | Ignored. Accepts the name or the numeric code (1 CUSTOMER, 2 DELIVERY, 3 MERCHANT, 4 ADMIN). Defaults to `"CUSTOMER"`. |
| `otp` | string | yes | Numeric code with OTP_LENGTH digits (4 in the current configuration). |
| `device` | DeviceInfo · nullable | no |  |


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `user_id` | string | yes |  |
| `login_channel` | LoginChannel | yes |  |
| `user_type` | string | yes | CUSTOMER, DELIVERY_PARTNER, MERCHANT_STAFF or ADMIN. |
| `session_type` | string | yes | `access` (full app session) or `onboarding` (customer registration only). |
| `role` | string · nullable | no | Primary role code for this app, e.g. manager, driver, customer. |
| `active_roles` | string[] | no | Distinct role codes allowed on this app. |
| `account_status` | string | yes |  |
| `approval_status` | string · nullable | no | Merchant, delivery-profile or customer approval state. |
| `profile_completion_status` | string · nullable | no | Customer only: NOT_STARTED, INCOMPLETE or COMPLETE. |
| `next_action` | NextAction | yes |  |
| `merchant` | MerchantSummary · nullable | no | Merchant and delivery apps only. |
| `delivery_profile` | DeliveryProfileSummary · nullable | no | Delivery app only. |
| `customer_profile` | CustomerProfileSummary · nullable | no | Customer app only, once details are submitted. |
| `token` | TokenPair | yes |  |
| `is_new_user` | bool | no | True when this verification created the account. Defaults to `false`. |
| `code` | string | no | Defaults to `"OTP_VERIFIED"`. |
| `message` | string | no | Defaults to `"OTP verified"`. |


**Error statuses**: `400`, `403`, `404`, `422`


### `POST /auth/token/refresh`

**Refresh Token**


**Request body**

| Field | Type | Required | Notes |
|---|---|---|---|
| `refresh_token` | string | yes |  |
| `device_id` | string · nullable | no | Deprecated: use device.device_id. |
| `device` | DeviceInfo · nullable | no | Send when the push token or app version changed; omitted values are kept. |


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `access_token` | string | yes |  |
| `refresh_token` | string | yes |  |
| `token_type` | TokenType | no | Defaults to `"Bearer"`. |
| `expires_in` | int | yes | Access-token lifetime in seconds. |


**Error statuses**: `401`, `403`, `422`


---

## Deliveries

The driver's work. Every one of these is scoped to the slips addressed to **this** driver; another driver's delivery returns `404`, never `403`.


### `GET /deliveries/history`

**Delivery History**


**Query parameters**

| Name | Type | Required | Notes |
|---|---|---|---|
| `period` | string | no |  |
| `page` | int | no |  |
| `limit` | int | no |  |


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `items` | HistoryDeliveryEntry[] | yes |  |
| `total` | int | yes |  |
| `page` | int | yes |  |
| `limit` | int | yes |  |


**Error statuses**: `401`, `403`, `422`


### `GET /deliveries/today`

**Todays Deliveries**


**Response** - an array of:

| Field | Type | Required | Notes |
|---|---|---|---|
| `id` | string | yes |  |
| `orderNumber` | string | yes |  |
| `status` | string | yes |  |
| `deliveryDate` | string | yes |  |
| `customer` | CustomerLocation | yes |  |
| `distanceKm` | float · nullable | no |  |
| `items` | app__modules__driver__schemas__DeliveryItemResponse[] | yes |  |
| `emptyReturns` | EmptyReturnItem[] | yes |  |
| `billing` | BillingSummary | yes |  |


**Error statuses**: `401`, `403`


### `GET /deliveries/{deliveryId}/completed-detail`

**Delivery Completed Detail**


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `id` | string | yes |  |
| `orderNumber` | string | yes |  |
| `status` | string | yes |  |
| `deliveryDate` | string | yes |  |
| `completedAt` | string | yes |  |
| `customer` | CustomerInfoDetail | yes |  |
| `deliveredItems` | app__modules__driver__schemas__DeliveryItemResponse[] | yes |  |
| `emptyItems` | app__modules__driver__schemas__DeliveryItemResponse[] | yes |  |
| `payment` | object | no |  |
| `driverNotes` | string · nullable | no |  |


**Error statuses**: `401`, `403`, `404`, `422`


### `POST /deliveries/{deliveryId}/confirm`

**Confirm Counts**


**Request body**

| Field | Type | Required | Notes |
|---|---|---|---|
| `deliveredItems` | DeliveredItemEntry[] | yes |  |
| `collectedEmpties` | CollectedEmptyEntry[] | yes |  |
| `payment` | PaymentEntry | yes |  |
| `driverNotes` | string · nullable | no |  |


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `deliveryId` | string | yes |  |
| `customerOtpRequired` | bool | yes |  |
| `otpChannel` | string | yes |  |
| `message` | string | yes |  |


**Error statuses**: `401`, `403`, `404`, `409`, `422`


### `POST /deliveries/{deliveryId}/generate-qr`

**Generate UPI QR as Base64 PNG**


**Request body**

| Field | Type | Required | Notes |
|---|---|---|---|
| `orderId` | string | yes | Must belong to the delivery in the path |
| `amount` | float | yes | Positive INR amount; encoded to two decimals |
| `notes` | string · nullable | no | UPI transaction note, maximum 200 characters |
| `upiId` | string | yes | Dynamic payee UPI ID, for example `merchant@bank` |
| `payeeName` | string | yes | Dynamic name shown in the payer's UPI app |


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `deliveryId` | string | yes |  |
| `orderId` | string | yes |  |
| `orderNumber` | string | yes |  |
| `amount` | float | yes |  |
| `upiId` | string | yes |  |
| `payeeName` | string | yes |  |
| `notes` | string · nullable | no |  |
| `upiString` | string | yes |  |
| `qrCodeBase64` | string | yes | Raw Base64 for a 300×300 PNG |
| `mimeType` | string | yes | Always `image/png` |

Render with `data:image/png;base64,<qrCodeBase64>`. This is not a payment-gateway call and does
not confirm or record a payment.


**Error statuses**: `401`, `403`, `404`, `409`, `422`


### `POST /deliveries/{deliveryId}/out-for-delivery`

**Out For Delivery**


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `deliveryId` | string | yes |  |
| `orderNumber` | string | yes |  |
| `status` | string | yes |  |
| `updatedAt` | string | yes |  |


**Error statuses**: `401`, `403`, `404`, `409`, `422`


### `PUT /deliveries/{deliveryId}/update-items`

**Update Items**


**Request body**

| Field | Type | Required | Notes |
|---|---|---|---|
| `updatedItems` | UpdateItemEntry[] | yes |  |
| `reason` | string | yes |  |


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `id` | string | yes |  |
| `orderNumber` | string | yes |  |
| `status` | string | yes |  |
| `deliveryDate` | string | yes |  |
| `customer` | CustomerLocation | yes |  |
| `distanceKm` | float · nullable | no |  |
| `items` | app__modules__driver__schemas__DeliveryItemResponse[] | yes |  |
| `emptyReturns` | EmptyReturnItem[] | yes |  |
| `billing` | BillingSummary | yes |  |


**Error statuses**: `401`, `403`, `404`, `409`, `422`


### `POST /deliveries/{deliveryId}/verify-customer-otp`

**Verify Customer Otp**


**Request body**

| Field | Type | Required | Notes |
|---|---|---|---|
| `otp` | string | yes |  |


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `deliveryId` | string | yes |  |
| `orderNumber` | string | yes |  |
| `status` | string | yes |  |
| `completedAt` | string | yes |  |
| `totalDeliveredQuantity` | int | yes |  |
| `deliveredItems` | app__modules__driver__schemas__DeliveryItemResponse[] | yes |  |
| `totalEmptyCollectedQuantity` | int | yes |  |
| `emptyCollectedItems` | app__modules__driver__schemas__DeliveryItemResponse[] | yes |  |
| `emptyDueSummary` | EmptyDueSummary | yes |  |
| `payment` | PaymentEntry | no |  |


**Error statuses**: `401`, `403`, `404`, `409`, `422`


### `POST /deliveries/{deliveryId}/verify-location`

**Verify Location**


**Request body**

| Field | Type | Required | Notes |
|---|---|---|---|
| `latitude` | float | yes |  |
| `longitude` | float | yes |  |


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `deliveryId` | string | yes |  |
| `isAtLocation` | bool | yes |  |
| `distanceMetersFromDestination` | float · nullable | no |  |
| `isLocationCaptured` | bool | yes |  |
| `message` | string | yes |  |


**Error statuses**: `401`, `403`, `404`, `409`, `422`


---

## Driver

The driver's own record, and what their van is carrying.


### `GET /driver/inventory`

**Van Inventory**


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `totalFullCylinders` | int | yes |  |
| `totalEmptyCylinders` | int | yes |  |
| `activeDeliveriesCount` | int | yes |  |
| `stockByType` | DriverInventoryLine[] | yes |  |


**Error statuses**: `401`, `403`


### `GET /driver/profile`

**My Profile**


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `id` | string | yes |  |
| `name` | string | yes |  |
| `phone` | string | yes |  |
| `vehicleNumber` | string · nullable | no |  |
| `role` | string | yes |  |
| `onDuty` | bool | yes |  |
| `avatarInitials` | string · nullable | no |  |
| `shiftStats` | ShiftStats · nullable | no |  |


**Error statuses**: `401`, `403`


### `PATCH /driver/status`

**Set Duty**


**Request body**

| Field | Type | Required | Notes |
|---|---|---|---|
| `onDuty` | bool | yes |  |


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `id` | string | yes |  |
| `name` | string | yes |  |
| `phone` | string | yes |  |
| `vehicleNumber` | string · nullable | no |  |
| `role` | string | yes |  |
| `onDuty` | bool | yes |  |
| `avatarInitials` | string · nullable | no |  |
| `shiftStats` | ShiftStats · nullable | no |  |


**Error statuses**: `401`, `403`, `404`, `409`, `422`


---

## Notifications

The in-app bell. A driver sees only what is addressed to them personally - never the merchant's shared notifications.


### `GET /notifications`

**Notifications**

Newest first.

A customer sees their own; staff see their merchant's, shared across the team
(spec §15). `read` is per user, so one person opening a notification does not hide
it from the rest.


**Query parameters**

| Name | Type | Required | Notes |
|---|---|---|---|
| `unreadOnly` | bool | no | Only the ones not yet read. |


**Response** - an array of:

| Field | Type | Required | Notes |
|---|---|---|---|
| `id` | string | yes |  |
| `title` | string | yes |  |
| `message` | string | yes |  |
| `severity` | Severity | yes |  |
| `category` | Category | yes |  |
| `createdAt` | string | yes |  |
| `read` | bool | yes |  |
| `referenceType` | ReferenceType · nullable | no |  |
| `referenceId` | string · nullable | no |  |


**Error statuses**: `401`, `403`, `422`


### `POST /notifications/read-all`

**Mark all read**


**Error statuses**: `401`, `403`


### `GET /notifications/unread-count`

**Unread count**

The bell badge, without fetching the list to count it.


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `unread` | int | yes |  |


**Error statuses**: `401`, `403`


### `GET /notifications/{notificationId}`

**Notification detail**

Someone else's notification is reported as 404, never 403.


**Response**

| Field | Type | Required | Notes |
|---|---|---|---|
| `id` | string | yes |  |
| `title` | string | yes |  |
| `message` | string | yes |  |
| `severity` | Severity | yes |  |
| `category` | Category | yes |  |
| `createdAt` | string | yes |  |
| `read` | bool | yes |  |
| `referenceType` | ReferenceType · nullable | no |  |
| `referenceId` | string · nullable | no |  |


**Error statuses**: `401`, `403`, `404`, `422`


### `PATCH /notifications/{notificationId}/read`

**Mark read (PATCH)**

The same write under the verb the delivery app calls.

The merchant and customer apps already ship against `POST`, and the delivery app against
`PATCH`. Marking something read is a bodyless state change, so neither verb is wrong -
and breaking a shipped app to settle the question would be.


**Error statuses**: `401`, `403`, `404`, `422`


### `POST /notifications/{notificationId}/read`

**Mark read**

Idempotent - marking an already-read notification read again is not an error.


**Error statuses**: `401`, `403`, `404`, `422`

