"""Environment-based application configuration."""
