"""Delivery API channel."""
