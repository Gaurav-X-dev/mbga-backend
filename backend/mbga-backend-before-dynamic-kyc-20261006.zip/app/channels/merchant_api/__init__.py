"""Merchant API channel."""
