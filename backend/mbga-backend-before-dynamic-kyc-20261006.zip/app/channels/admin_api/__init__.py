"""Admin API channel."""
