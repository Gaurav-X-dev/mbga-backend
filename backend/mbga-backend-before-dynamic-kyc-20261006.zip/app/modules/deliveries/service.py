"""Delivery slip reads and writes (spec §10).

This is the module where four others meet, and every write here is the atomic join between them:

    order status  <->  slip status  <->  stock ledger  <->  notifications

A dispatch moves the order to OUT_FOR_DELIVERY, marks the slip DISPATCHED and tells the
customer - **in one transaction**. Any of those happening without the others is a real-world
inconsistency somebody has to unpick by hand: a customer told their order is coming when it is
still in the godown, an order stuck OUT_FOR_DELIVERY for a van that never loaded.

**Stock moves at confirmation, not at dispatch.** Cylinders on a van are still the merchant's:
the delivery can fail and they come straight back. So the counts drop when the customer actually
receives them, and a dispatch only *checks* that the load can be filled - against filled stock
minus what the vans already out are carrying, or `filled` would stay whole while a van was on the
road and a second one could be loaded from the same cylinders.

Order of operations is the same everywhere: check everything that can refuse, then write
everything, then commit once.

Only merchant staff reach these routes. A customer follows their order through the order
endpoints; the slip is the godown's document, and it carries the crew's names and the vehicle.
"""

from dataclasses import dataclass
from datetime import UTC, date, datetime
from uuid import uuid4

from fastapi import status as http_status
from sqlalchemy import Select, case, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.app import Settings
from app.modules.customers.business_schemas import Address
from app.modules.customers.models import CustomerDeliverySite, CustomerProfile
from app.modules.deliveries import codes, validation
from app.modules.deliveries.constants import (
    ALL_STATUSES,
    IN_TRANSIT_STATUSES,
    LIVE_STATUSES,
    MAX_CODE_ATTEMPTS,
    STATUS_RANK,
    ConfirmationMethod,
    DeliveryStatus,
)
from app.modules.deliveries.models import DeliverySlip, DeliverySlipItem
from app.modules.deliveries.numbering import SlipNumberAllocator
from app.modules.deliveries.schemas import (
    ConfirmDeliveryRequest,
    CreateDeliverySlipRequest,
    DeliveryItemResponse,
    DeliverySlipResponse,
    FailDeliveryRequest,
)
from app.modules.delivery_users.models import DeliveryProfile
from app.modules.inventory.ledger import StockLedger
from app.modules.notifications.events import deliveries as delivery_events
from app.modules.notifications.events import orders as order_events
from app.modules.notifications.events import payments as payment_events
from app.modules.orders import transitions
from app.modules.orders.constants import ORDER_LABELS, OrderStatus
from app.modules.orders.models import Order, OrderItem, OrderStatusHistory
from app.modules.payments.invoicing import InvoiceRaiser
from app.modules.pricing.constants import CylinderType
from app.modules.users.models import User
from app.shared.business.actor import BusinessActor
from app.shared.crypto.field_cipher import FieldCipher
from app.shared.exceptions.api_error import ApiError
from app.shared.notifications.outbox import NotificationOutboxWriter


def _not_found() -> ApiError:
    """A slip outside the actor's merchant is not found, never forbidden.

    Slip numbers are sequential and guessable by design, so a 403 would confirm that another
    merchant has a slip at that id.
    """
    return ApiError("DELIVERY_NOT_FOUND", http_status.HTTP_404_NOT_FOUND)


@dataclass
class SlipFilters:
    """Spec §10.1's query: one status or `ALL`, and a free-text search."""

    status: str | None = None
    search: str | None = None


class DeliveryService:
    def __init__(self, session: AsyncSession, actor: BusinessActor, settings: Settings) -> None:
        self.session = session
        self.actor = actor
        self.settings = settings
        self.merchant_id = actor.require_merchant_id()
        self.notifications = NotificationOutboxWriter(session)
        self.confirmation_code_cipher = FieldCipher(
            settings.document_cipher_secret,
            purpose="delivery-confirmation-code",
        )

    # --- Reads ------------------------------------------------------------------------------

    async def list_slips(self, filters: SlipFilters) -> list[DeliverySlipResponse]:
        """The Delivery & Dispatch list (spec §10.1).

        Ordered as a work queue rather than a log: what is on the road first, then what has to
        go out, then what went wrong, and delivered slips last because they need nobody. The
        rank is pushed into SQL as a CASE so the ordering survives the row limit - sorting in
        Python after a LIMIT would order whichever arbitrary page came back.
        """
        rank = case(STATUS_RANK, value=DeliverySlip.status, else_=len(STATUS_RANK))
        statement = self._scope(select(DeliverySlip)).order_by(
            rank.asc(),
            DeliverySlip.scheduled_date.desc(),
            # MySQL DATETIME has no fractional seconds, so same-day slips need a stable
            # tie-break or the list reshuffles between refreshes.
            DeliverySlip.slip_number.desc(),
        )
        statement = self._apply_status(statement, filters.status)
        statement = self._apply_search(statement, filters.search)
        slips = list(await self.session.scalars(statement))
        return [await self._view(slip) for slip in slips]

    async def get(self, slip_id: str) -> DeliverySlipResponse:
        return await self._view(await self._owned(slip_id))

    # --- Raising a slip ---------------------------------------------------------------------

    async def create(
        self, payload: CreateDeliverySlipRequest, *, commit: bool = True
    ) -> DeliverySlipResponse:
        """Raise a slip against a confirmed order (an addition - see the schema's docstring).

        Nothing leaves the godown here and no stock moves: this is the loading instruction. The
        stock check happens when the driver sets off, deliberately, because a slip is often
        raised the evening before and the refill truck comes in the morning.

        `commit=False` for the caller that confirms an order and assigns it in one step: the two
        belong in one transaction, so an order whose van could not be assigned is not left
        accepted with nobody on it.
        """
        order = await self._slippable_order(payload.order_id)
        vehicle = validation.check_vehicle_number(payload.vehicle_number)
        scheduled_date = _scheduled(payload.scheduled_date, order)
        driver = await self._crew_member(
            payload.driver_user_id,
            role="driver",
            vehicle_number=vehicle,
            scheduled_date=scheduled_date,
        )
        helper = await self._crew_member(
            payload.helper_user_id,
            role="helper",
            vehicle_number=vehicle,
            scheduled_date=scheduled_date,
        )
        driver_name = validation.resolve_driver_name(
            payload, await self._account_name(driver, payload.driver_user_id)
        )
        method = validation.check_confirmation_method(payload.confirmation_method)

        now = datetime.now(UTC)
        items = await self._order_items(order.id)
        destination = await self._site_coordinates(order)
        slip = DeliverySlip(
            id=str(uuid4()),
            slip_number=await SlipNumberAllocator(self.session, self.merchant_id).allocate(),
            merchant_id=self.merchant_id,
            order_id=order.id,
            order_number=order.order_number,
            customer_id=order.customer_id,
            customer_name=order.customer_name,
            customer_mobile=await self._customer_mobile(order.customer_id),
            delivery_site_name=order.delivery_site_name,
            address_line1=order.address_line1,
            address_line2=order.address_line2,
            address_city=order.address_city,
            address_state=order.address_state,
            address_pincode=order.address_pincode,
            # Copied like the address, and null for most slips: an order usually goes to the
            # customer's registered address rather than a named site, and nobody surveys those.
            destination_latitude=destination[0],
            destination_longitude=destination[1],
            # Copied verbatim from the order so the slip and the order read identically.
            items_summary=order.items_summary,
            cylinders_allocated=order.total_cylinders,
            vehicle_number=vehicle,
            driver_user_id=payload.driver_user_id,
            driver_name=driver_name,
            helper_user_id=payload.helper_user_id,
            helper_name=validation.resolve_helper_name(
                payload, await self._account_name(helper, payload.helper_user_id)
            ),
            scheduled_date=scheduled_date,
            empties_collected=0,
            confirmation_method=method.value,
            # Minted at dispatch, not here: a slip raised the evening before should not carry a
            # live code all night, and the code is only useful once the van is moving.
            confirmation_code_hash=None,
            confirmation_attempts=0,
            status=DeliveryStatus.SCHEDULED.value,
            created_by_name=self.actor.display_name,
            created_by_user_id=self.actor.user_id,
            created_at=now,
            updated_at=now,
        )
        self.session.add(slip)
        # Flushed before the lines: they are linked by a foreign key but by no ORM relationship,
        # so the unit of work does not order the inserts for us.
        await self.session.flush()
        for position, item in enumerate(items):
            self.session.add(
                DeliverySlipItem(
                    slip_id=slip.id,
                    cylinder_type=item.cylinder_type,
                    quantity=item.quantity,
                    position=position,
                )
            )
        # The order now points at its slip, which is what the order detail screen reads. Its
        # **status does not move**: raising a slip is planning, and nothing has physically
        # happened until the van is dispatched. The order stays CONFIRMED until then, and goes
        # straight to OUT_FOR_DELIVERY when it does.
        order.delivery_slip_id = slip.id
        order.updated_at = now
        self._notify_assignment(slip)
        if commit:
            await self.session.commit()
        else:
            # The caller owns the transaction, but the slip has to exist before anything reads
            # it back - the view below among them.
            await self.session.flush()
        return await self._view(slip)

    # --- Dispatch ---------------------------------------------------------------------------

    async def dispatch(self, slip_id: str, *, commit: bool = True) -> DeliverySlipResponse:
        """Mark a slip dispatched - the van has set off (spec §10.3).

        Called by the **delivery app**, not the office: the customer's "on the way" notification
        goes out from here, and the office pressing it meant a customer was told their cylinders
        were on the road while the driver had not opened his phone. `commit=False` is for the
        driver setting off with a whole round at once, where the slips move together or not at
        all.

        The stock is **checked but not deducted**. Cylinders on a van are still the merchant's -
        the delivery can fail and bring them back - so the counts move at handover instead, in
        `confirm()`.

        The check measures what the godown can actually load: filled stock minus what the vans
        already on the road are carrying. Without that subtraction `filled` would stay whole while
        a van was out, and a second van could be loaded from the same cylinders.
        """
        slip = await self._owned(slip_id)
        self._require_status(slip, DeliveryStatus.DISPATCHED, ready=DeliveryStatus.SCHEDULED)
        order = await self._order_of(slip, lock=True)
        now = datetime.now(UTC)

        # Refuses with spec §10.3's message, and writes nothing either way.
        await StockLedger(self.session, self.merchant_id).check_available(
            await self._lines(slip.id),
            committed=await self._committed(exclude_slip_id=slip.id),
            now=now,
        )

        # The code the customer will read out at the gate. Minted here, told to them in the
        # notification below. The hash verifies it; the encrypted copy lets only the owning
        # customer's order endpoint show it again after an app refresh.
        code = (
            codes.generate() if slip.confirmation_method == ConfirmationMethod.OTP.value else None
        )
        slip.status = DeliveryStatus.DISPATCHED.value
        slip.dispatched_at = now
        slip.dispatched_by_name = self.actor.display_name
        slip.confirmation_code_hash = codes.fingerprint(code) if code else None
        slip.confirmation_code_encrypted = (
            self.confirmation_code_cipher.encrypt(code) if code else None
        )
        slip.confirmation_attempts = 0
        slip.updated_at = now
        transitions.advance(
            self.session,
            order,
            OrderStatus.OUT_FOR_DELIVERY,
            by_name=self.actor.display_name,
            by_user_id=self.actor.user_id,
            by_role=self.actor.role_label,
            source=self.actor.source,
            # Spec §10.3's wording, verbatim: it is what a customer ringing up is read back.
            note=f"Vehicle {slip.vehicle_number} · {slip.driver_name}",
            now=now,
        )
        # Kept repeatable for safe retries and legacy orders that may already have more than one
        # slip. New failed deliveries cancel the order and cannot be rescheduled.
        await self.notifications.queue_repeatable(
            delivery_events.out_for_delivery(
                slip.customer_id,
                order.id,
                slip.order_number,
                driver_name=slip.driver_name,
                confirmation_code=code,
            )
        )
        if commit:
            await self.session.commit()
        else:
            await self.session.flush()
        return await self._view(slip, reveal_code=code)

    async def mark_on_location(
        self, slip_id: str, *, now: datetime | None = None, commit: bool = True
    ) -> datetime:
        """Mark the driver as arrived and tell both the customer and merchant.

        Idempotent because a handset may retry after losing the response. The slip and order move
        together, the order history is appended once, and both notifications share that same
        transaction.
        """
        slip = await self._owned(slip_id)
        if slip.status == DeliveryStatus.ON_LOCATION.value:
            arrived_at = await self.session.scalar(
                select(OrderStatusHistory.changed_at)
                .where(
                    OrderStatusHistory.order_id == slip.order_id,
                    OrderStatusHistory.status == OrderStatus.ON_LOCATION.value,
                )
                .order_by(OrderStatusHistory.changed_at.desc(), OrderStatusHistory.id.desc())
                .limit(1)
            )
            if commit:
                await self.session.commit()
            else:
                await self.session.flush()
            return arrived_at or slip.updated_at
        self._require_status(
            slip,
            DeliveryStatus.ON_LOCATION,
            ready=DeliveryStatus.DISPATCHED,
        )
        order = await self._order_of(slip, lock=True)
        moment = now or datetime.now(UTC)
        slip.status = DeliveryStatus.ON_LOCATION.value
        slip.updated_at = moment
        moved = transitions.advance(
            self.session,
            order,
            OrderStatus.ON_LOCATION,
            by_name=self.actor.display_name,
            by_user_id=self.actor.user_id,
            by_role=self.actor.role_label,
            source=self.actor.source,
            note=f"Driver {slip.driver_name} reached the delivery location.",
            now=moment,
        )
        if moved:
            self.notifications.queue(
                delivery_events.on_location_customer(
                    slip.customer_id,
                    order.id,
                    slip.order_number,
                    driver_name=slip.driver_name,
                )
            )
            self.notifications.queue(
                delivery_events.on_location_merchant(
                    self.merchant_id,
                    order.id,
                    slip.order_number,
                    driver_name=slip.driver_name,
                    customer_name=slip.customer_name,
                )
            )
        if commit:
            await self.session.commit()
        else:
            await self.session.flush()
        return moment

    # --- Confirmation -----------------------------------------------------------------------

    async def confirm(self, slip_id: str, payload: ConfirmDeliveryRequest) -> DeliverySlipResponse:
        """Confirm a handover (spec §10.4).

        The code is checked before anything moves, and a wrong one costs an attempt and is
        committed on its own - so the count survives a client that retries in a loop, and the
        slip is not confirmed by the eleventh guess.
        """
        slip = await self._owned(slip_id)
        self._require_status(
            slip,
            DeliveryStatus.DELIVERED,
            ready=(DeliveryStatus.DISPATCHED, DeliveryStatus.ON_LOCATION),
        )
        collected = validation.check_empties(payload.empties_collected, slip.cylinders_allocated)
        await self._check_code(slip, payload.otp)

        order = await self._order_of(slip, lock=True)
        now = datetime.now(UTC)
        slip.status = DeliveryStatus.DELIVERED.value
        slip.delivered_at = now
        slip.empties_collected = collected
        slip.confirmed_by_name = self.actor.display_name
        slip.note = validation.check_note(payload.note)
        # Spent. Keeping the hash would leave a code that still verifies against a slip that can
        # no longer be confirmed, which is a secret with no purpose.
        slip.confirmation_code_hash = None
        slip.confirmation_code_encrypted = None
        slip.updated_at = now

        # The cylinders have now actually changed hands, so this is where they come off the
        # books. Before this moment they were on a van and still the merchant's - and anything
        # the driver brings back is still on it, so only what he handed over is booked.
        lines = await self._delivered_lines(slip.id)
        ledger = StockLedger(self.session, self.merchant_id)
        if lines:
            await ledger.deliver(
                lines,
                reference_id=slip.id,
                recorded_by_user_id=self.actor.user_id,
                recorded_by_name=self.actor.display_name,
                now=now,
            )
        if collected:
            await ledger.collect_empties(
                {_primary_type(lines or await self._lines(slip.id)): collected},
                reference_id=slip.id,
                recorded_by_user_id=self.actor.user_id,
                recorded_by_name=self.actor.display_name,
                now=now,
            )
        transitions.advance(
            self.session,
            order,
            OrderStatus.DELIVERED,
            by_name=self.actor.display_name,
            by_user_id=self.actor.user_id,
            by_role=self.actor.role_label,
            source=self.actor.source,
            note=_delivered_note(collected, slip.cylinders_allocated),
            now=now,
        )
        # The bill is raised here rather than at dispatch (spec §10.4 leaves the choice to the
        # backend). Handover is the honest moment: until the customer has the cylinders there is
        # nothing to bill for, and a failed delivery would otherwise leave an invoice for goods
        # that came back on the van. Raising it is idempotent, so a retried confirmation bills
        # nothing twice.
        invoice = await InvoiceRaiser(self.session, self.merchant_id).raise_for(order, now=now)
        self.notifications.queue(
            delivery_events.delivered(
                slip.customer_id, order.id, slip.order_number, cylinders=slip.cylinders_allocated
            )
        )
        self.notifications.queue(
            payment_events.invoice_raised(
                slip.customer_id,
                invoice.id,
                invoice.invoice_number,
                invoice.total_amount,
                slip.order_number,
            )
        )
        await self.session.commit()
        return await self._view(slip)

    # --- Failure ----------------------------------------------------------------------------

    async def fail(self, slip_id: str, payload: FailDeliveryRequest) -> DeliverySlipResponse:
        """Record a slip that did not deliver (an addition - see the schema's docstring).

        A slip that comes back loaded needs **no stock movement at all**, because nothing ever
        left the books: the counts only drop at handover. The van is simply released, and the
        cylinders were the merchant's the whole time.

        **No customer OTP**, unlike a successful handover. The code proves the customer received
        the cylinders, and nobody can produce it when the reason for failing is that the customer
        was not there - which is what most failed runs are. Requiring it would leave exactly those
        deliveries uncloseable: the van back at the godown and the order still claiming to be out.

        The driver is accountable by the reason they type instead. It goes onto the slip, into the
        order's trail with their name and app, and into the customer's notification.

        A failed delivery is final for the order; a later attempt starts as a new order.
        """
        slip = await self._owned(slip_id)
        self._require_status(
            slip,
            DeliveryStatus.FAILED,
            ready=(DeliveryStatus.DISPATCHED, DeliveryStatus.ON_LOCATION),
        )
        now = datetime.now(UTC)

        slip.status = DeliveryStatus.FAILED.value
        slip.failure_reason = payload.reason.strip()
        slip.confirmation_code_hash = None
        slip.confirmation_code_encrypted = None
        slip.updated_at = now
        # The order is cancelled with the slip. A failed delivery used to leave it out for
        # delivery with nothing carrying it - not deliverable, because the slip had failed, and
        # not cancellable, because the table stopped there - so the order sat for ever claiming
        # to be on a van. Cancelling tells the customer where they stand and lets them order
        # again, which is a worse day than a redelivery but an honest one.
        order = await self._order_of(slip, lock=True)
        transitions.advance(
            self.session,
            order,
            OrderStatus.CANCELLED,
            by_name=self.actor.display_name,
            by_user_id=self.actor.user_id,
            by_role=self.actor.role_label,
            source=self.actor.source,
            note=f"Delivery failed: {payload.reason.strip()}",
            now=now,
        )
        self.notifications.queue(
            delivery_events.delivery_failed(
                self.merchant_id, slip.order_id, slip.order_number, reason=payload.reason.strip()
            )
        )
        self.notifications.queue(
            order_events.order_cancelled_customer(slip.customer_id, order.id, slip.order_number)
        )
        if slip.driver_user_id:
            self.notifications.queue(
                delivery_events.unassigned_from_driver(
                    slip.driver_user_id, slip.id, slip.order_number, reason=payload.reason.strip()
                )
            )
        await self.session.commit()
        return await self._view(slip)

    # --- Guards -----------------------------------------------------------------------------

    def _require_status(
        self,
        slip: DeliverySlip,
        target: DeliveryStatus,
        *,
        ready: DeliveryStatus | tuple[DeliveryStatus, ...],
    ) -> None:
        """Refuse with the reason the app shows, not a generic conflict.

        Spec §10.4 asks for two distinct messages - "already confirmed" and "not been dispatched
        yet" - because they call for opposite actions from whoever is holding the phone.
        """
        ready_statuses = (ready,) if isinstance(ready, DeliveryStatus) else ready
        if slip.status in {item.value for item in ready_statuses}:
            return
        if slip.status == target.value:
            raise ApiError(
                "DELIVERY_ALREADY_SETTLED",
                http_status.HTTP_409_CONFLICT,
                f"Slip {slip.slip_number} has already been {target.value.lower()}.",
            )
        raise ApiError(
            "DELIVERY_NOT_READY",
            http_status.HTTP_409_CONFLICT,
            validation.not_ready_message(slip.slip_number, slip.status, ready_statuses[0]),
        )

    def _settled(self, slip: DeliverySlip) -> ApiError:
        return ApiError(
            "DELIVERY_ALREADY_SETTLED",
            http_status.HTTP_409_CONFLICT,
            f"Slip {slip.slip_number} is {slip.status.lower()} and can no longer be changed.",
        )

    async def _check_code(self, slip: DeliverySlip, submitted: str | None) -> None:
        """Verify the proof-of-delivery code, spending one attempt on a wrong one."""
        if slip.confirmation_method != ConfirmationMethod.OTP.value:
            return
        if slip.confirmation_attempts >= MAX_CODE_ATTEMPTS:
            raise ApiError(
                "DELIVERY_CODE_LOCKED",
                http_status.HTTP_409_CONFLICT,
                "Too many incorrect codes for this delivery. Confirm it from the office.",
            )
        if not codes.is_well_formed(submitted):
            # Malformed, so nothing is hashed and no attempt is spent: a letter in the box is a
            # typo, not a guess.
            raise validation.bad_code()
        if codes.matches(
            submitted or "",
            slip.confirmation_code_hash,
            allow_mock=self.settings.dev_expose_otp_in_response,
        ):
            return
        slip.confirmation_attempts += 1
        # Committed on its own, because the caller's transaction is about to be abandoned by the
        # raise. Without this the attempt count resets on every retry and the budget is fiction.
        await self.session.commit()
        raise validation.bad_code()

    # --- Lookups ----------------------------------------------------------------------------

    def _scope(self, statement: Select) -> Select:
        """Every slip query starts here. Applied as a `WHERE`, never as a later filter."""
        return statement.where(DeliverySlip.merchant_id == self.merchant_id)

    async def _owned(self, slip_id: str) -> DeliverySlip:
        slip = await self.session.scalar(
            self._scope(select(DeliverySlip)).where(DeliverySlip.id == slip_id)
        )
        if slip is None:
            raise _not_found()
        return slip

    async def _slippable_order(self, order_id: str) -> Order:
        """The order this slip is for, and whether a van may be loaded for it.

        Another merchant's order is a 404, matching how `OrderService` reports one.
        """
        order = await self.session.scalar(
            select(Order).where(Order.id == order_id, Order.merchant_id == self.merchant_id)
        )
        if order is None:
            raise ApiError("ORDER_NOT_FOUND", http_status.HTTP_404_NOT_FOUND)
        # Asked before the status check, not after, because the status check now admits an order
        # that is still OUT_FOR_DELIVERY - which is only safe once we know nothing is carrying it.
        existing = await self.session.scalar(
            self._scope(select(DeliverySlip)).where(
                DeliverySlip.order_id == order.id,
                DeliverySlip.status.in_(LIVE_STATUSES),
            )
        )
        if existing is not None:
            raise ApiError(
                "DELIVERY_ALREADY_EXISTS",
                http_status.HTTP_409_CONFLICT,
                f"Order {order.order_number} is already on slip {existing.slip_number}.",
            )
        validation.check_order_state(order)
        return order

    async def _site_coordinates(self, order: Order) -> tuple[float | None, float | None]:
        """Where the van is being sent, when anybody has recorded it.

        Only a named delivery site can carry coordinates; an order to the customer's registered
        address has none, which is the common case. Returning `(None, None)` rather than raising
        is deliberate - a delivery must never depend on a latitude the office never typed in.
        """
        if not order.delivery_site_id:
            return None, None
        site = await self.session.get(CustomerDeliverySite, order.delivery_site_id)
        if site is None:
            return None, None
        return site.latitude, site.longitude

    async def _order_of(self, slip: DeliverySlip, *, lock: bool = False) -> Order:
        """The slip's order, locked when this call is about to move its status.

        Without the lock a dispatch and a customer's cancellation each read the order before the
        other commits, both pass their own transition check against that stale row, and whichever
        writes second wins. The cancellation is the one that loses, because the dispatch is the
        slower request - which is how a cancelled order comes back as out for delivery.
        """
        statement = select(Order).where(
            Order.id == slip.order_id, Order.merchant_id == self.merchant_id
        )
        if lock:
            statement = statement.with_for_update()
        order = await self.session.scalar(statement)
        if order is None:
            # The slip's own foreign key guarantees the row; if it is gone the data is broken and
            # a 404 on the slip is the honest answer rather than a 500.
            raise _not_found()
        return order

    async def _crew_member(
        self,
        user_id: str | None,
        *,
        role: str,
        vehicle_number: str,
        scheduled_date: date,
    ) -> DeliveryProfile | None:
        """A delivery profile of this merchant, active and approved, or a coded refusal.

        Checked rather than trusted: a slip naming a blocked driver, or one belonging to another
        merchant, would send that person a job they cannot open and leave the office believing
        it is assigned.
        """
        if not user_id:
            return None
        # Locked: this is the row the availability rules are read from, so two assignments naming
        # the same driver have to take it in turns. The second then sees the slip the first just
        # raised and is refused, rather than both reading "free" and both succeeding.
        profile = await self.session.scalar(
            select(DeliveryProfile)
            .where(
                DeliveryProfile.user_id == user_id,
                DeliveryProfile.merchant_id == self.merchant_id,
            )
            .with_for_update()
        )
        return validation.check_crew(
            profile,
            role=role,
            busy=await self._has_conflicting_assignment(
                user_id,
                role=role,
                vehicle_number=vehicle_number,
                scheduled_date=scheduled_date,
            ),
        )

    async def _has_conflicting_assignment(
        self, user_id: str, *, role: str, vehicle_number: str, scheduled_date: date
    ) -> bool:
        """Whether this person is assigned to a different live delivery round.

        A round contains several order slips, so another slip on the same vehicle and date is
        compatible. A different vehicle/date or switching between driver and helper is a real
        conflict.
        """
        assignments = list(
            await self.session.scalars(
                select(DeliverySlip).where(
                    DeliverySlip.merchant_id == self.merchant_id,
                    DeliverySlip.status.in_(LIVE_STATUSES),
                    or_(
                        DeliverySlip.driver_user_id == user_id,
                        DeliverySlip.helper_user_id == user_id,
                    ),
                )
            )
        )
        role_field = "driver_user_id" if role == "driver" else "helper_user_id"
        return any(
            getattr(slip, role_field) != user_id
            or slip.vehicle_number != vehicle_number
            or slip.scheduled_date != scheduled_date
            for slip in assignments
        )

    async def _account_name(self, profile, user_id: str | None) -> str | None:
        """The crew member's real name, for the slip and for the customer's notification.

        One query, and only when a crew member was picked from the list - slip creation is not a
        list screen. Returns None for a hired van, which is what lets a typed name through.
        """
        if profile is None or not user_id:
            return None
        user = await self.session.get(User, user_id)
        if user is None:
            return None
        return user.full_name or user.username or profile.employee_code

    async def _order_items(self, order_id: str) -> list[OrderItem]:
        return list(
            await self.session.scalars(
                select(OrderItem).where(OrderItem.order_id == order_id).order_by(OrderItem.position)
            )
        )

    async def _committed(self, *, exclude_slip_id: str | None = None) -> dict[CylinderType, int]:
        """Cylinders on this merchant's vans: dispatched, not yet confirmed or failed.

        This is the difference between what the godown holds and what it can still load. Counts
        only drop at handover now, so `filled` stays whole while a van is out - without this
        subtraction a second van could be loaded from the cylinders the first one is carrying.

        The slip being dispatched is excluded, so a retry of its own dispatch does not count
        against itself.
        """
        statement = (
            select(DeliverySlipItem.cylinder_type, func.sum(DeliverySlipItem.quantity))
            .join(DeliverySlip, DeliverySlip.id == DeliverySlipItem.slip_id)
            .where(
                DeliverySlip.merchant_id == self.merchant_id,
                DeliverySlip.status.in_(IN_TRANSIT_STATUSES),
            )
            .group_by(DeliverySlipItem.cylinder_type)
        )
        if exclude_slip_id:
            statement = statement.where(DeliverySlip.id != exclude_slip_id)
        return {
            CylinderType(cylinder_type): int(total or 0)
            for cylinder_type, total in await self.session.execute(statement)
        }

    async def _lines(self, slip_id: str) -> dict[CylinderType, int]:
        """The slip's cylinders as allocated, which is what the van is answerable for."""
        rows = list(
            await self.session.scalars(
                select(DeliverySlipItem)
                .where(DeliverySlipItem.slip_id == slip_id)
                .order_by(DeliverySlipItem.position)
            )
        )
        return {CylinderType(row.cylinder_type): row.quantity for row in rows}

    async def _delivered_lines(self, slip_id: str) -> dict[CylinderType, int]:
        """What actually changed hands, which is what comes off the books.

        Falls back to the allocation per line, because `delivered_quantity` is only set by the
        driver app: the office's own confirmation endpoint records no per-line counts, and a slip
        from before that column existed has none either. A line delivered as zero is kept out
        entirely rather than passed to the ledger as a no-op movement.
        """
        rows = list(
            await self.session.scalars(
                select(DeliverySlipItem)
                .where(DeliverySlipItem.slip_id == slip_id)
                .order_by(DeliverySlipItem.position)
            )
        )
        lines = {
            CylinderType(row.cylinder_type): (
                row.quantity if row.delivered_quantity is None else row.delivered_quantity
            )
            for row in rows
        }
        return {kind: quantity for kind, quantity in lines.items() if quantity > 0}

    async def _items_view(self, slip_id: str) -> list[DeliveryItemResponse]:
        rows = list(
            await self.session.scalars(
                select(DeliverySlipItem)
                .where(DeliverySlipItem.slip_id == slip_id)
                .order_by(DeliverySlipItem.position)
            )
        )
        return [
            DeliveryItemResponse(
                cylinder_type=CylinderType(row.cylinder_type),
                cylinder_label=_label(row.cylinder_type),
                quantity=row.quantity,
            )
            for row in rows
        ]

    async def _customer_mobile(self, customer_id: str) -> str | None:
        return await self.session.scalar(
            select(CustomerProfile.mobile_number).where(CustomerProfile.id == customer_id)
        )

    # --- Filters ----------------------------------------------------------------------------

    @staticmethod
    def _apply_status(statement: Select, value: str | None) -> Select:
        """`status = SCHEDULED | ... | ALL` (spec §10.1).

        An unrecognised value returns nothing rather than 422: it is a chip on a screen, and a
        stale chip should show an empty list, not an error dialog.
        """
        if not value or value.upper() == ALL_STATUSES:
            return statement
        return statement.where(DeliverySlip.status == value.upper())

    @staticmethod
    def _apply_search(statement: Select, value: str | None) -> Select:
        """Slip number, order number, customer name, vehicle number (spec §10.1).

        Also the customer's mobile, because that is what somebody holding a phone actually has
        when a customer rings to ask where their cylinders are.
        """
        term = (value or "").strip()
        if not term:
            return statement
        pattern = f"%{term}%"
        return statement.where(
            or_(
                DeliverySlip.slip_number.like(pattern),
                DeliverySlip.order_number.like(pattern),
                DeliverySlip.customer_name.like(pattern),
                DeliverySlip.vehicle_number.like(pattern),
                DeliverySlip.customer_mobile.like(pattern),
                DeliverySlip.driver_name.like(pattern),
            )
        )

    # --- Notifications ----------------------------------------------------------------------

    def _notify_assignment(self, slip: DeliverySlip) -> None:
        """Tell the driver the job is theirs.

        Only when the slip names a driver with an account: a hired van's driver has no phone to
        notify, and the office tells them directly. Keyed on the slip, so the same driver can be
        assigned many jobs without the events colliding on the outbox's uniqueness constraint.
        """
        if not slip.driver_user_id:
            return
        self.notifications.queue(
            delivery_events.assigned_to_driver(
                slip.driver_user_id,
                slip.id,
                slip.order_number,
                customer_name=slip.customer_name,
            )
        )

    # --- Views ------------------------------------------------------------------------------

    async def _view(
        self, slip: DeliverySlip, *, reveal_code: str | None = None
    ) -> DeliverySlipResponse:
        # The money comes off the order rather than the slip: one billing record, one set of
        # numbers. The order's prices were frozen at placement, so this cannot drift.
        money = await self.session.execute(
            select(Order.subtotal, Order.gst_percent, Order.gst_amount, Order.total_amount).where(
                Order.id == slip.order_id
            )
        )
        subtotal, gst_percent, gst_amount, total_amount = money.first() or (0, 0, 0, 0)
        return DeliverySlipResponse(
            id=slip.id,
            slip_number=slip.slip_number,
            order_id=slip.order_id,
            order_number=slip.order_number,
            customer_id=slip.customer_id,
            customer_name=slip.customer_name,
            delivery_address=Address(
                line1=slip.address_line1 or "",
                line2=slip.address_line2,
                city=slip.address_city or "",
                state=slip.address_state or "",
                pincode=slip.address_pincode or "",
            ),
            delivery_site_name=slip.delivery_site_name,
            items=await self._items_view(slip.id),
            items_summary=slip.items_summary,
            cylinders_allocated=slip.cylinders_allocated,
            subtotal=subtotal,
            gst_percent=gst_percent,
            gst_amount=gst_amount,
            total_amount=total_amount,
            vehicle_number=slip.vehicle_number,
            driver_name=slip.driver_name,
            helper_name=slip.helper_name,
            scheduled_date=slip.scheduled_date,
            dispatched_at=slip.dispatched_at,
            delivered_at=slip.delivered_at,
            empties_collected=slip.empties_collected,
            # Derived, so it cannot drift from the two numbers it is made of.
            pending_pickup=max(slip.cylinders_allocated - slip.empties_collected, 0),
            confirmation_method=ConfirmationMethod(slip.confirmation_method),
            status=DeliveryStatus(slip.status),
            failure_reason=slip.failure_reason,
            note=slip.note,
            dev_confirmation_code=(
                reveal_code if reveal_code and self.settings.dev_expose_otp_in_response else None
            ),
        )


def _label(cylinder_type: str) -> str:
    try:
        return ORDER_LABELS[CylinderType(cylinder_type)]
    except (KeyError, ValueError):
        return cylinder_type


def _scheduled(requested: date | None, order: Order) -> date:
    """The slip's date: what was asked for, or the day the cut-off already decided.

    Defaulting to the order's own `scheduled_delivery_date` means the common case needs no input
    and cannot contradict what the customer was promised at placement. A calendar day, not an
    instant - a van goes out on a date, and there is no delivery slot to carry a time.
    """
    return requested if requested is not None else order.scheduled_delivery_date


def _primary_type(lines: dict[CylinderType, int]) -> CylinderType:
    """Which cylinder the returned empties are booked against.

    Empties come back as bare cylinders and the driver is not asked to split them by type, so
    they are booked against the largest line on the slip - the one they almost certainly are.
    Stated here rather than hidden in the caller because it is an approximation, and the person
    reconciling the empty bucket deserves to find it written down.
    """
    return max(lines, key=lambda cylinder: (lines[cylinder], cylinder.value))


def _delivered_note(collected: int, allocated: int) -> str:
    pending = max(allocated - collected, 0)
    if not pending:
        return f"{collected} empties collected"
    return f"{collected} of {allocated} empties collected · {pending} pending pickup"
