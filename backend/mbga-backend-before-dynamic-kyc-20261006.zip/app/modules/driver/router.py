"""The delivery app's routes (API_REFERENCE §6-§10). Delivery channel only."""

from typing import Annotated

from fastapi import APIRouter, Depends, Path, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.app import Settings, get_settings
from app.modules.authentication.constants import LoginChannel
from app.modules.customers.dependencies import ActorDep
from app.modules.driver.schemas import (
    CancelDeliveryRequest,
    CancelDeliveryResponseData,
    CompletedDeliveryDetailResponseData,
    ConfirmDeliveryRequest,
    ConfirmDeliveryResponseData,
    DriverDeliveryResponse,
    DriverInventoryResponseData,
    DriverProfileResponseData,
    GenerateQrRequest,
    GenerateQrResponseData,
    HistoryDeliveriesResponseData,
    OutForDeliveryBulkRequest,
    OutForDeliveryResponseData,
    UpdateDutyRequest,
    UpdateItemsRequest,
    VerifyCustomerOtpRequest,
    VerifyCustomerOtpResponseData,
    VerifyLocationRequest,
    VerifyLocationResponseData,
)
from app.modules.driver.service import DeliveryFilters, DriverService
from app.shared.authorization.dependencies import require_login_channel, require_permission
from app.shared.database.session import get_db_session
from app.shared.date_time.business_calendar import business_today
from app.shared.exceptions.openapi import error_responses

DeliveryIdPath = Annotated[str, Path(alias="deliveryId", max_length=36)]

_delivery_only = Depends(require_login_channel(LoginChannel.DELIVERY))
_read_guards = [_delivery_only, Depends(require_permission("deliveries.view"))]
_write_guards = [_delivery_only, Depends(require_permission("deliveries.update_status"))]


def build_service(
    actor: ActorDep,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    settings: Annotated[Settings, Depends(get_settings)],
) -> DriverService:
    return DriverService(session, actor, settings)


ServiceDep = Annotated[DriverService, Depends(build_service)]

deliveries_router = APIRouter(prefix="/deliveries", tags=["Delivery Deliveries"])
driver_router = APIRouter(prefix="/driver", tags=["Delivery Driver"])


# --- Deliveries ------------------------------------------------------------------------------


@deliveries_router.get(
    "/today",
    response_model=list[DriverDeliveryResponse],
    dependencies=_read_guards,
    responses=error_responses(401, 403),
)
async def todays_deliveries(service: ServiceDep) -> list[DriverDeliveryResponse]:
    data = await service.list_deliveries(DeliveryFilters(scheduled_on=business_today()))
    return data


@deliveries_router.post(
    "/out-for-delivery",
    response_model=list[OutForDeliveryResponseData],
    dependencies=_write_guards,
    responses=error_responses(401, 403, 404, 409, 422),
    summary="Set off with a whole round",
)
async def out_for_delivery_many(
    payload: OutForDeliveryBulkRequest, service: ServiceDep
) -> list[OutForDeliveryResponseData]:
    """The van has left the godown carrying all of these.

    All or nothing: one press is one event, so slips that half moved would describe a van that is
    both out and not. Each order moves to `OUT_FOR_DELIVERY` and each customer is told.
    """
    return await service.out_for_delivery_many(payload.delivery_ids)


@deliveries_router.post(
    "/{deliveryId}/out-for-delivery",
    response_model=OutForDeliveryResponseData,
    dependencies=_write_guards,
    responses=error_responses(401, 403, 404, 409, 422),
)
async def out_for_delivery(
    delivery_id: DeliveryIdPath, service: ServiceDep
) -> OutForDeliveryResponseData:
    return await service.out_for_delivery(delivery_id)


@deliveries_router.post(
    "/{deliveryId}/cancel",
    response_model=CancelDeliveryResponseData,
    dependencies=_write_guards,
    responses=error_responses(401, 403, 404, 409, 422),
    summary="Cancel an unsuccessful delivery with customer OTP",
)
async def cancel_delivery(
    delivery_id: DeliveryIdPath,
    payload: CancelDeliveryRequest,
    service: ServiceDep,
) -> CancelDeliveryResponseData:
    """Close the dispatched slip as failed and its order as cancelled.

    The same OTP sent when the driver set off proves that the customer acknowledged the outcome.
    A later delivery requires a new order; there is no reschedule action.
    """
    return await service.cancel_delivery(delivery_id, payload)


@deliveries_router.post(
    "/{deliveryId}/verify-location",
    response_model=VerifyLocationResponseData,
    dependencies=_write_guards,
    responses=error_responses(401, 403, 404, 409, 422),
    summary="I am on location",
)
async def verify_location(
    delivery_id: DeliveryIdPath, payload: VerifyLocationRequest, service: ServiceDep
) -> VerifyLocationResponseData:
    """Capture the driver's GPS fix and publish ON_LOCATION to all three apps."""
    return await service.verify_location(delivery_id, payload)


@deliveries_router.put(
    "/{deliveryId}/update-items",
    response_model=DriverDeliveryResponse,
    dependencies=_write_guards,
    responses=error_responses(401, 403, 404, 409, 422),
)
async def update_items(
    delivery_id: DeliveryIdPath, payload: UpdateItemsRequest, service: ServiceDep
) -> DriverDeliveryResponse:
    return await service.update_items(delivery_id, payload)


@deliveries_router.post(
    "/{deliveryId}/generate-qr",
    response_model=GenerateQrResponseData,
    dependencies=_write_guards,
    responses=error_responses(401, 403, 404, 409, 422),
    summary="Generate UPI QR as Base64 PNG",
)
async def generate_qr(
    delivery_id: DeliveryIdPath, payload: GenerateQrRequest, service: ServiceDep
) -> GenerateQrResponseData:
    """Generate a QR locally; this does not contact or verify with a payment gateway."""
    return await service.generate_qr(delivery_id, payload)


@deliveries_router.post(
    "/{deliveryId}/confirm",
    response_model=ConfirmDeliveryResponseData,
    dependencies=_write_guards,
    responses=error_responses(401, 403, 404, 409, 422),
)
async def confirm_counts(
    delivery_id: DeliveryIdPath, payload: ConfirmDeliveryRequest, service: ServiceDep
) -> ConfirmDeliveryResponseData:
    return await service.confirm_counts(delivery_id, payload)


@deliveries_router.post(
    "/{deliveryId}/verify-customer-otp",
    response_model=VerifyCustomerOtpResponseData,
    dependencies=_write_guards,
    responses=error_responses(401, 403, 404, 409, 422),
)
async def verify_customer_otp(
    delivery_id: DeliveryIdPath, payload: VerifyCustomerOtpRequest, service: ServiceDep
) -> VerifyCustomerOtpResponseData:
    return await service.verify_customer_otp(delivery_id, payload.otp)


@deliveries_router.get(
    "/{deliveryId}/completed-detail",
    response_model=CompletedDeliveryDetailResponseData,
    dependencies=_read_guards,
    responses=error_responses(401, 403, 404),
)
async def delivery_completed_detail(
    delivery_id: DeliveryIdPath, service: ServiceDep
) -> CompletedDeliveryDetailResponseData:
    return await service.get_completed_detail(delivery_id)


@deliveries_router.get(
    "/history",
    response_model=HistoryDeliveriesResponseData,
    dependencies=_read_guards,
    responses=error_responses(401, 403),
)
async def delivery_history(
    service: ServiceDep,
    period: str = Query("today"),
    page: int = Query(1, ge=1),
    limit: Annotated[int, Query(ge=1, le=200)] = 20,
) -> HistoryDeliveriesResponseData:
    return await service.list_history(period, page, limit)


# --- Driver ---------------------------------------------------------------------------------


@driver_router.get(
    "/inventory",
    response_model=DriverInventoryResponseData,
    dependencies=_read_guards,
    responses=error_responses(401, 403),
)
async def van_inventory(service: ServiceDep) -> DriverInventoryResponseData:
    return await service.inventory()


@driver_router.patch(
    "/status",
    response_model=DriverProfileResponseData,
    dependencies=_write_guards,
    responses=error_responses(401, 403, 404, 409),
)
async def set_duty(payload: UpdateDutyRequest, service: ServiceDep) -> DriverProfileResponseData:
    return await service.set_duty(payload.on_duty)


@driver_router.get(
    "/profile",
    response_model=DriverProfileResponseData,
    dependencies=_read_guards,
    responses=error_responses(401, 403),
)
async def my_profile(service: ServiceDep) -> DriverProfileResponseData:
    return await service.profile()
