"""Dynamic permissions module."""
