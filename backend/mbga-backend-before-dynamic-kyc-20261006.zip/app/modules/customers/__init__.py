"""Customer onboarding module."""
