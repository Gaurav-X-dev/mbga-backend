"""Admin dashboard module."""
