"""Central authentication module."""
