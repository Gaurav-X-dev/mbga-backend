"""User exceptions placeholder."""
