"""User permissions placeholder."""
