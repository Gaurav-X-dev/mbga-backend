"""Shared constants placeholder."""
