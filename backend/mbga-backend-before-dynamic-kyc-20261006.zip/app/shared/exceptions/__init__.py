"""Shared exception helpers placeholder."""
