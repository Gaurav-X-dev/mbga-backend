"""Authorization primitives."""
